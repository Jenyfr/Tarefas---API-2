package com.exercicio.tarefas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TarefasApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(TarefasApiApplication.class, args);
    }
}
